document.getElementById("btn").addEventListener("click", () => {
  document.getElementById("input").click();
});
